package NUST.UniProject.UniSlotSelection

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class UniSlotSelectionApplication

fun main(args: Array<String>) {
	runApplication<UniSlotSelectionApplication>(*args)
}
